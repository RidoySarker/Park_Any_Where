(function ($) {
    "use strict";

    $('#summernote').summernote({
        placeholder: 'Hello World!',
        tabsize: 1,
        height: 300
    });

    $('#summernote2').summernote({
        placeholder: 'Hello World!',
        tabsize: 1,
        height: 600
    });

})(jQuery);