<link rel="stylesheet" href="{{asset('backend_assets/style.css')}}">
{{-- <link rel="stylesheet" href="{{asset('backend_assets/css/toastr.min.css')}}"> --}}
<link rel="stylesheet" href="{{asset('backend_assets/css/default-assets/datatables.bootstrap4.css')}}">
<link rel="stylesheet" href="{{asset('backend_assets/css/bootstrap.min.css')}}">
@stack('css')
<link rel="stylesheet" href="{{asset('backend_assets/css/default-assets/select2.min.css')}}">
<link rel="stylesheet" href="{{asset('backend_assets/css/default-assets/datatables.bootstrap4.css')}}">
<link rel="stylesheet" href="{{asset('backend_assets/css/default-assets/jquery.tagsinput.min.css')}}">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">

