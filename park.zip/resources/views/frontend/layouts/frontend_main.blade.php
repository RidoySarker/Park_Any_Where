@include('frontend.layouts.frontend_css')
@include('frontend.layouts.frontend_navbar')

@yield('content')

@include('frontend.layouts.frontend_footer')
@include('frontend.layouts.frontend_js')